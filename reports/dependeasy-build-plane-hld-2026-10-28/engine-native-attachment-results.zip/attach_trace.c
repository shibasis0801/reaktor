#include <jni.h>
#include <jvmti.h>
#include <pthread.h>
#include <execinfo.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static FILE *output;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static int recorded;

static void JNICALL thread_start(jvmtiEnv *jvmti, JNIEnv *env, jthread thread) {
    jvmtiThreadInfo info = {0};
    if ((*jvmti)->GetThreadInfo(jvmti, thread, &info) != JVMTI_ERROR_NONE) return;
    if (info.name && strncmp(info.name, "Thread-", 7) == 0) {
        pthread_mutex_lock(&lock);
        if (recorded++ < 512) {
            uint64_t tid = 0;
            char native_name[256] = {0};
            pthread_threadid_np(NULL, &tid);
            pthread_getname_np(pthread_self(), native_name, sizeof(native_name));
            fprintf(output, "ATTACH_TRACE pthread=%p tid=%llu java=%s native=%s\n", (void *)pthread_self(), tid, info.name, native_name);
            fflush(output);
            void *frames[64];
            int count = backtrace(frames, 64);
            backtrace_symbols_fd(frames, count, fileno(output));
            fputs("ATTACH_END\n", output);
            fflush(output);
        }
        pthread_mutex_unlock(&lock);
    }
    if (info.name) (*jvmti)->Deallocate(jvmti, (unsigned char *)info.name);
    if (info.thread_group) (*env)->DeleteLocalRef(env, info.thread_group);
    if (info.context_class_loader) (*env)->DeleteLocalRef(env, info.context_class_loader);
}

JNIEXPORT jint JNICALL Agent_OnLoad(JavaVM *vm, char *options, void *reserved) {
    jvmtiEnv *jvmti = NULL;
    if (!options || (*vm)->GetEnv(vm, (void **)&jvmti, JVMTI_VERSION_1_2) != JNI_OK) return JNI_ERR;
    output = fopen(options, "w");
    if (!output) return JNI_ERR;
    jvmtiEventCallbacks callbacks = {0};
    callbacks.ThreadStart = thread_start;
    if ((*jvmti)->SetEventCallbacks(jvmti, &callbacks, sizeof(callbacks)) != JVMTI_ERROR_NONE) return JNI_ERR;
    return (*jvmti)->SetEventNotificationMode(jvmti, JVMTI_ENABLE, JVMTI_EVENT_THREAD_START, NULL) == JVMTI_ERROR_NONE ? JNI_OK : JNI_ERR;
}
